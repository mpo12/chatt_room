﻿<?php


$data0 =  $_POST["comment0"]  ;
$data1 =  $_POST["comment1"]  ;
$data2 =  $_POST["comment2"]  ;

 
 
$link = dirname(__FILE__)  ;
$c2 =  $link .  "/../3adad.txt" ;


$read = file_get_contents($c2) ;


file_put_contents( $c2 , $read + 1 ) ;

 
$aa =  $link .  "/../05ala3da/$read.txt"  ;

file_put_contents( $aa  , $data1 . "-" . $data2  . "-" . $data0  ) ;



