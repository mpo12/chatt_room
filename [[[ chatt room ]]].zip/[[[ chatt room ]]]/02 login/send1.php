﻿<?php

$msg =  $_POST["comment1"]  ;

$link = dirname(__FILE__)  ;
$text = $link . "/../chat1.txt" ;

file_put_contents(
$text ,
$msg    . "#" ,
FILE_APPEND

);




