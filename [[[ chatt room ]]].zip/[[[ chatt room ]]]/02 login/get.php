﻿<?php

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $uesr = $_POST["eml"];
    $pass = $_POST["pass"];
    
//~~~~~~~~~~~~~~~~~~~~~

$link = dirname(__FILE__)  ;
$g = $link .  "/../05ala3da" ;


$az = scandir( $g ) ;


$m0 = count($az) ;
$m = $m0 - 1 ;


for( $i = 1 ; $i <  $m  ; $i++){

$aa1 =  $link .  "/../05ala3da/$i.txt" ;
     
$read = file_get_contents($aa1) ;
     
$idu = explode( "-" , $read )  ;


   if( $idu[0]  == $uesr 
   	               &&
   	  $idu[1]  == $pass ){
   	
   	 $varo = $idu[2]  ;
   	
   	echo 
   	 '
   	
   	
<//~~~~~~~~~~~~~~~~  !>
<//~~~~~~~~~~~~~~~~  !>
<//~~~~~~~~~~~~~~~~  !>  


<html>

<head>
    <title>safha</title>
    <link rel="stylesheet" type="text/css" href="01blabla.css" />
    <link rel="stylesheet" type="text/css" href="02blabla.css" />
</head>


<body>

<script src="http//:code.jquery.com/jquery-2.0.0.min.js"></script>
<!---------------------------------------------->

<div class="head">

    <img class="logo" src="img1/logo.png">

    <img class="sahm" src="img1/pp.png">
</div>


<!---------------------------------------------->
<div class="line"></div>
<!---------------------------------------------->


<!---------------------------------------------->
<div class="line"></div>
<!---------------------------------------------->

<div class="line1"></div>

<!---------------------------------------------->

<div class="bady">

</div>

<!---------------------------------------------->

<div class="hk" > 
     '
  . $varo . ':  ' .
     '
</div>

<!---------------------------------------------->







<!---------------------------------------------->

<div class="down">



<form>
    <input class="text" type="text" id="txt" placeholder="...اكتب شيئا" >

    <button class="send" >
        <img class="img_send" src="img1/send.png">
    </button>

</form>

</div>

<!---------------------------------------------->
<script src="codss2.js"></script>


</body>

</html>




<//~~~~~~~~~~~~~~~~  !>
<//~~~~~~~~~~~~~~~~  !>
<//~~~~~~~~~~~~~~~~  !>  
       '
   	 ;

   	 
   	 $x  = 1 ;
   	 break;
   } 
        
}

//~~~~~


echo @$x  or die("
	
	 <p style='font-size:300%;' >
    كلمة السر خطأ او الامايل اعد المحاوله 
     </p>
    
	")  ;
	
 






//~~~~~~~~~~~~~~~~~~~~~

}

else{

    echo "
    <p style='font-size:300%;' >
    لن يسمح لك ب الدخول دون تسجيل ارجع وسجل دخولك 
     </p>
    " ;

}











