﻿<?php

$link = dirname(__FILE__)  ;
$text = $link . "/../chat1.txt" ;


if(filesize($text) != 0){

$read = file_get_contents($text);

$line = explode("#" , $read );
 
foreach ( $line as $i ){
    echo    $i  ;
    echo "<br>" ;
   };

}


















