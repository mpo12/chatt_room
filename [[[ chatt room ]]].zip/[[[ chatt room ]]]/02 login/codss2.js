﻿
$(document).ready(function() {

        function getdata(){
                    $.ajax({ 
            url:"get1.php" ,
            type: "POST"  , 
            success: function(resp){
              $(".bady").html(resp);
            }
        });
        
 //~~~~~~~~~~~~~~~~
        
    $("#chat").animate({
        scrollTop: "10000"
},1000);
      }

 //~~~~~~~~~~~~~~~~
    
$(".send").click(function(e){
        e.preventDefault();

   $.ajax({
           method: "POST" ,
           url: "send1.php" , 
          data: { 
comment1 : $(".hk").html() + $(".text").val()
       },
          });

document.getElementById("txt").value = "" ;    

});








setInterval (function(){

    getdata();

},1000);


});





















